d3.csv("Science.csv", function(science) {
science.forEach(function(science) {
  science.latitude = +science.latitude;
  science.longitude = +science.longitude;
  science.birth_year = +science.birth_year;
  science.color = "blue";
  science.border = "white";
  science.score = +science.historical_popularity_index;
  science.sex = science.sex;
});

d3.csv("Religion.csv", function(religion) {
religion.forEach(function(religion) {
  religion.latitude = +religion.latitude;
  religion.longitude = +religion.longitude;
  religion.birth_year = +religion.birth_year;
  religion.color = "red";
  religion.border = "pink";
  religion.score = religion.historical_popularity_index;
  religion.sex = religion.sex;
});

var scale = 2;
var time = 1950;

var Religion = religion.filter(function(d) {return [d.latitude, d.longitude, d.country, d.birth_year,d.full_name]});

var Science = science.filter(function(d) {return [d.latitude, d.longitude, d.country, d.birth_year,d.full_name]});

var svgcontainer = d3.select("body")
.append("svg")
.attr("width",3500/scale)
.attr("height",2085/scale)
.attr("x",0)
.attr("y",0);

var imgs = svgcontainer.selectAll("image").data([0]);
            imgs.enter()
            .append("svg:image")
            .attr("xlink:href", "worldmap.jpg")
            .attr('x',0)
            .attr('y',0)
            .attr('width',3500/scale)
            .attr('height',2085/scale);
/*
var text = svgcontainer
.selectAll("text")
.data(latitude)
.enter()
.append("text")

var textattr = text
.text(function(d){return d.full_name})
.attr("y",function(d){return (-10.8714788732394*d.latitude+1101.76452464789)/scale})
.attr("x",function(d) {return (9.52850372982857*d.longitude+1638.75672872412)/scale})
.style("fill",function(d){if (((time-d.birth_year)<100) && ((time-d.birth_year)>0)) {return "black"} else {return "none"}})
.style("font-size","60px")
*/

var sciences = svgcontainer
.selectAll("circle")
.data(Science)
.enter()
.append("circle");

var scienceattr = sciences
.attr("cy",function(d){return (-10.8714788732394*d.latitude+1101.76452464789)/scale
})
.attr("cx",function(d) {return (9.52850372982857*d.longitude+1638.75672872412)/scale
})/*
.attr("r", function(d) {return 0.03*d.score**2/scale})
.style("fill",function(d){if (((time-d.birth_year)<100) && ((time-d.birth_year)>0)) {return d.color} else {return "none"}})
.attr("stroke",function(d){if (((time-d.birth_year)<100) && ((time-d.birth_year)>0)) {return d.border} else {return "none"}})
.attr("stroke-width",4/scale)*/
.style("opacity",0.6);

var religions = svgcontainer
.selectAll("circle")
.data(Religion)
.enter()
.append("circle");

var religionattr = religions
.attr("cy",function(d){return (-10.8714788732394*d.latitude+1101.76452464789)/scale
})
.attr("cx",function(d) {return (9.52850372982857*d.longitude+1638.75672872412)/scale
})
.attr("r", function(d) {return 0.03*d.score**2/scale})
.style("fill",function(d){if (((time-d.birth_year)<100) && ((time-d.birth_year)>0)) {return d.color} else {return "none"}})
.attr("stroke",function(d){if (((time-d.birth_year)<100) && ((time-d.birth_year)>0)) {return d.border} else {return "none"}})
.attr("stroke-width",4/scale)
.style("opacity",0.6);

d3.select("#year").on("input", function() {
  update(+this.value);
});


/*
var names = d3.selectAll("circle")
.on("mousemove", function(){
  personattr.style("opacity",1)
})
.on("mouseout", function(){
  personattr.style("opacity",0.8)
})
*/
function update(year) {
  d3.select("#year-value").text(year);
  d3.select("#year").property("value", year);

  d3.selectAll("circle")
  .style("fill",function(d){if (((year-d.birth_year)<100) && ((year-d.birth_year)>=0)) {return d.color} else {return "none"}})
  .attr("stroke",function(d){if (((year-d.birth_year)<100) && ((year-d.birth_year)>=0)) {return d.border} else {return "none"}})
  .attr("r", function(d) {return 0.03*d.score**2/scale})

  d3.selectAll("text")
  .style("fill",function(d){if (((year-d.birth_year)<100) && ((year-d.birth_year)>=0)) {return "black"} else {return "none"}})

}

update(2018)
});
});
