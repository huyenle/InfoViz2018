# InfoViz2018 - Group 19
Information Visualisation Project 2018 UvA
Henna Lee-10915842, 
Huyen Le-11638400, 
Gianluca Francone-11862262, 
Tobias Beers-10556249 and 
Renée van Hoek-10713565
